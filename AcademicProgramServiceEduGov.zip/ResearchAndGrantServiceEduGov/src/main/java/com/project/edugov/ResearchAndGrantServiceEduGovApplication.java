package com.project.edugov;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResearchAndGrantServiceEduGovApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResearchAndGrantServiceEduGovApplication.class, args);
	}

}
